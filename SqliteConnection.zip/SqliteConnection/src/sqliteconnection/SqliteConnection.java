package sqliteconnection;

import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SqliteConnection {
    private DbHandler db;        
    
    SqliteConnection(){
       
        db=new DbHandler();
        
    }
    
    public static void main(String[] args) {
        SqliteConnection sql=new SqliteConnection();
        double max=99.0;
        double min=0.0;
        while (true){
            ArrayList<Request> list=sql.db.getRequests();
            ArrayList<Request> testlist=sql.db.getRequestsTest();
            
            ArrayList<Request> deleteRequests=sql.db.deleteRequests();
            ArrayList<Request> testdeleteRequests=sql.db.deleteRequestsTest();
            
            for(int i=0;i<deleteRequests.size();i++){
                
                if(deleteRequests.get(i).getDeleteyesorno().equals("y"))
                {
                    sql.db.deleteFromRequests(deleteRequests.get(i).getRequestid());
                    sql.db.deleteFromResponses(deleteRequests.get(i).getRequestid());
                }
            
            }
            for(int i=0;i<testdeleteRequests.size();i++){
                
                if(testdeleteRequests.get(i).getDeleteyesorno().equals("y"))
                {
                    sql.db.deleteFromRequestsTest(testdeleteRequests.get(i).getRequestid());
                    sql.db.deleteFromResponsesTest(testdeleteRequests.get(i).getRequestid());
                }
            
            }
            Random rand = new Random(); 
            if(list.size()==0){
                //System.out.println("No new requests found");
            }
            for(int i=0;i<list.size();i++){
                //System.out.println(list.get(i).toString());
                String userId=list.get(i).getRequestid();
                String requestCommand=list.get(i).getRequestcommand();
                String deleteYesOrNo=list.get(i).getDeleteyesorno();
                String isVisitedYesOrNo=list.get(i).getIsVisitedYesOrNo();
                double randomBet= Math.random() * (max - min + 1) + min;
                String[] token = Double.toString(randomBet).split("\\.");
                token[1]=token[1].substring(0,2);
                String back=token[0]+"."+token[1];
                randomBet=Double.parseDouble(back);
                Request request=new Request(userId,requestCommand,deleteYesOrNo,isVisitedYesOrNo);
                sql.db.updateVisited(userId);

                //System.out.println(request.getDeleteyesorno());

                boolean userExistInRequest=sql.db.userExist(request.getRequestid());
                boolean userExistInBalance=sql.db.userExistInBalance(request.getUid());
                if(userExistInRequest==true && userExistInBalance==true )
                {
                    String bal=sql.db.getBalance(request.getUid());
                    double balance=Double.parseDouble(bal);
                    double bet=Double.parseDouble(request.getBetAmount());
                    if(balance>=bet)
                    {
                        if(randomBet<request.getBetRange())
                        {
                            System.out.println("UserWin");
                            double profit=bet*(sql.db.getHouse_edge()/request.getBetRange())-bet;
                            balance=balance+profit;
                            bal=Double.toString(balance);
                            if(bal.contains(".") ){
                                int decimal=bal.split("\\.")[1].length();
                                int beforedecimal=bal.split("\\.")[0].length();
                                if(decimal>8){
                                    int dif=decimal-8;
                                    bal=bal.substring(0,beforedecimal+1+decimal-dif);
                                }
                            }

                            sql.db.updateBalance(request.getUid(), bal);
                            String gameResult="";
                            gameResult+="Congratulations! Dice roll result was "+randomBet +" and your new balance = "+bal;
                            sql.db.insertIntoResponses(request.getRequestid(), gameResult, request.getDeleteyesorno());
                            boolean insertIntoTab=sql.db.insertIntoBets(request.getUid(),Double.toString(request.getBetRange()) , request.getBetAmount(),Double.toString(randomBet) ,Double.toString(request.getBetRange()) ,Double.toString(profit) ,bal);


                        }
                        else
                        {
                            System.out.println("LOSS");
                            balance=balance-bet;
                            bal=Double.toString(balance);
                            if(bal.contains(".") ){
                                int decimal=bal.split("\\.")[1].length();
                                int beforedecimal=bal.split("\\.")[0].length();
                                if(decimal>8){
                                    int dif=decimal-8;
                                    bal=bal.substring(0,beforedecimal+1+decimal-dif);
                                }
                            }
                            sql.db.updateBalance(request.getUid(), bal);

                            String gameResult="";
                            gameResult+="Sorry! Dice roll result was "+randomBet +" and your new balance = "+bal;
                            sql.db.insertIntoResponses(request.getRequestid(), gameResult, request.getDeleteyesorno());
                            boolean insertIntoTab=sql.db.insertIntoBets(request.getUid(),Double.toString(request.getBetRange()) , request.getBetAmount(),Double.toString(randomBet) ,Double.toString(request.getBetRange()) ,Double.toString(bet) ,bal);

                        }

                    }
                    else{

                        System.out.println("\nYou do not have sufficient coins for this game");
                    }



                }
                else
                {
                    System.out.println("User Not Found");

                }
                
            }
            try {
                //System.out.println("Sleep for 5 seconds");
                Thread.sleep(000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            //-----------------------Test Loop----------------------------------------
            
            for(int i=0;i<testlist.size();i++){
                //System.out.println(list.get(i).toString());
                String userId=testlist.get(i).getRequestid();
                String requestCommand=testlist.get(i).getRequestcommand();
                String deleteYesOrNo=testlist.get(i).getDeleteyesorno();
                String isVisitedYesOrNo=testlist.get(i).getIsVisitedYesOrNo();
                double randomBet= Math.random() * (max - min + 1) + min;
                String[] token = Double.toString(randomBet).split("\\.");
                token[1]=token[1].substring(0,2);
                String back=token[0]+"."+token[1];
                randomBet=Double.parseDouble(back);
                Request request=new Request(userId,requestCommand,deleteYesOrNo,isVisitedYesOrNo);
                sql.db.updateVisitedTest(userId);

                //System.out.println(request.getDeleteyesorno());

                boolean userExistInRequest=sql.db.userExistTest(request.getRequestid());
                boolean userExistInBalance=sql.db.userExistInBalanceTest(request.getUid());
                if(userExistInRequest==true && userExistInBalance==true )
                {
                    String bal=sql.db.getBalanceTest(request.getUid());
                    double balance=Double.parseDouble(bal);
                    double bet=Double.parseDouble(request.getBetAmount());
                    if(balance>=bet)
                    {
                        if(randomBet<request.getBetRange())
                        {
                            System.out.println("UserWin");
                            double profit=bet*(sql.db.getHouse_edge()/request.getBetRange())-bet;
                            balance=balance+profit;
                            bal=Double.toString(balance);
                            if(bal.contains(".") ){
                                int decimal=bal.split("\\.")[1].length();
                                int beforedecimal=bal.split("\\.")[0].length();
                                if(decimal>8){
                                    int dif=decimal-8;
                                    bal=bal.substring(0,beforedecimal+1+decimal-dif);
                                }
                            }

                            sql.db.updateBalanceTest(request.getUid(), bal);
                            String gameResult="";
                            gameResult+="Congratulations! Dice roll result was "+randomBet +" and your new balance = "+bal;
                            sql.db.insertIntoResponsesTest(request.getRequestid(), gameResult, request.getDeleteyesorno());
                            boolean insertIntoTab=sql.db.insertIntoBetsTest(request.getUid(),Double.toString(request.getBetRange()) , request.getBetAmount(),Double.toString(randomBet) ,Double.toString(request.getBetRange()) ,Double.toString(profit) ,bal);


                        }
                        else
                        {
                            System.out.println("LOSS");
                            balance=balance-bet;
                            bal=Double.toString(balance);
                            if(bal.contains(".") ){
                                int decimal=bal.split("\\.")[1].length();
                                int beforedecimal=bal.split("\\.")[0].length();
                                if(decimal>8){
                                    int dif=decimal-8;
                                    bal=bal.substring(0,beforedecimal+1+decimal-dif);
                                }
                            }
                            sql.db.updateBalanceTest(request.getUid(), bal);

                            String gameResult="";
                            gameResult+="Sorry! Dice roll result was "+randomBet +" and your new balance = "+bal;
                            sql.db.insertIntoResponsesTest(request.getRequestid(), gameResult, request.getDeleteyesorno());
                            boolean insertIntoTab=sql.db.insertIntoBetsTest(request.getUid(),Double.toString(request.getBetRange()) , request.getBetAmount(),Double.toString(randomBet) ,Double.toString(request.getBetRange()) ,Double.toString(bet) ,bal);

                        }

                    }
                    else{

                        System.out.println("\nYou do not have sufficient coins for this game");
                    }



                }
                else
                {
                    System.out.println("User Not Found");

                }

            }
            try {
                //System.out.println("Sleep for 5 seconds");
                Thread.sleep(000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            }

        
        }
        
               
            
    }

}
