package sqliteconnection;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DbHandler {
    private Connection con;
    private String DbLocation="C:\\Users\\mauri\\Downloads\\UpdatedProject_rar\\SqliteConnection\\db\\sampleTestDB.db";
    private String fileFolder="db";
    private double house_edge;
    
    private String DBURL = "jdbc:sqlite:";

    DbHandler() 
    {
        BufferedReader br=null;
        FileReader fr=null;
   
        try{
            fr = new FileReader(fileFolder+"\\diceBot-Config.txt");
            br = new BufferedReader(fr);
            String s = null;
            s = br.readLine();
            DbLocation=s.substring(s.indexOf("=")+1);
            s = br.readLine();
            house_edge=Double.parseDouble(s.substring(s.indexOf("=")+1));
            //System.out.println(house_edge);
        }catch(Exception io){
            System.out.println(io);
        }
          
        
    }
    private void connection()
    { 
        
        try {
            Class.forName("org.sqlite.JDBC");
            con=(Connection) DriverManager.getConnection(DBURL+DbLocation);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) {
            Logger.getLogger(DbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }


    }
    
    private void closeConnection()
    {  
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public double getHouse_edge() {
        return house_edge;
    }
    
    
    
    
    public ArrayList<Request> getRequests(){
        connection();
          try {
            String query="select * from Requests where visitedyesorno='n' or visitedyesorno='N'  ";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            ArrayList<Request> list=new ArrayList<Request>();
            while(rs.next()){
                String id=rs.getString(1);
                String command=rs.getString(2);
                String delete=rs.getString(3);
                String visit=rs.getString(4);
                Request r=new Request(id,command,delete,visit);
                list.add(r);
            }
            closeConnection();
            return list;
        } catch (Exception ex) {
            System.err.println(ex);
            closeConnection();
            return new ArrayList<Request>();
        }
        
        
    }
 
    public ArrayList<Request> deleteRequests(){
        connection();
          try {
            String query="select * from Requests where deleteyesorno='y'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            ArrayList<Request> list=new ArrayList<Request>();
            while(rs.next()){
                String id=rs.getString(1);
                String command=rs.getString(2);
                String delete=rs.getString(3);
                String visit=rs.getString(4);
                Request r=new Request(id,command,delete,visit);
                list.add(r);
            }
            closeConnection();
            return list;
        } catch (Exception ex) {
            System.err.println(ex);
            closeConnection();
            return new ArrayList<Request>();
        }
        
        
    }
 
    public boolean updateBalance(String userID,String balance)    {
        this.connection();
        PreparedStatement prst=null;
        String query="update balances set bal=? where uid=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
       

        prst.setString(1,balance);
        prst.setString(2, userID);
       
        int rows=prst.executeUpdate();
        closeConnection();
        if(rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            closeConnection();
            e.printStackTrace();
            return false;
            
        }
	
        
    }
 
    public boolean updateVisited(String userID)   {
        this.connection();
        PreparedStatement prst=null;
        String query="update requests set visitedyesorno='y' where requestid=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
       

        prst.setString(1, userID);
       
        int rows=prst.executeUpdate();
        closeConnection();
        
        if(rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
        	return false;
            
        }
	
        
    }
    
    public String getBalance(String uid)   {
        try 
        {
            this.connection();
            String query="select bal from Balances where uid='"+uid+"'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            String balance=null;
            if(rs.next()){
                balance=rs.getString(1);
                closeConnection();
        
                return balance;
            }
            else
                closeConnection();
        
                return balance;
        }
        catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
            return null;
            
        }
        
    }
    
    public ArrayList<Balance> getBalances(){
          try {
            this.connection();
            String query="select * from Balances";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            ArrayList<Balance> list=new ArrayList<Balance>();
            while(rs.next()){
                String uid=rs.getString(1);
                String bal=rs.getString(2);
                Balance r=new Balance(uid,bal);
                list.add(r);
            }
            closeConnection();
        
            return list;
        } catch (Exception ex) {
            closeConnection();
        
            System.err.println(ex);
            return null;
        }
        
        
    }
    
    public boolean userExist(String userId){
        try {
            this.connection();
            String query="select * from requests where requestid='"+userId+"'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
           // ArrayList<Balance> list=new ArrayList<Balance>();
            if(rs.next()){
                closeConnection();
        
                return true;
            }
            closeConnection();
        
            return false;
        }
        catch(Exception e)
        {
            this.connection();
            e.printStackTrace();
            return false;        
        }
            
        
    }
    
    public boolean userExistInBalance(String userId)    {
        
        try {
            connection();
            String query="select * from balances where uid='"+userId+"'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
           // ArrayList<Balance> list=new ArrayList<Balance>();
            if(rs.next()){
                closeConnection();
        
                return true;
            }
            closeConnection();
        
            return false;
        }
        catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
            return false;        
        }
            
        
    
    }
    
    public boolean insertIntoBalanaces(String uid,String balance){
          try {
              connection();
            String query="insert into Balances(uid,bal) values (?,?)";
            PreparedStatement prst=con.prepareStatement(query);
            prst.setString(1,uid);
            prst.setString(2,balance);
            prst.execute();
            closeConnection();
        
            return true;
            // TODO code application logic here
        } catch (SQLException ex) {
            closeConnection();
        
            Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }
    
    public boolean insertIntoBets(String uid,String winChance,String betAmount,String rollResult,String result,String  profitOrLossAmount, String balance){
          try {
              this.connection();
            String query="insert into bets values (?,?,?,?,?,?,?)";
            PreparedStatement prst=con.prepareStatement(query);
            prst.setString(1,uid);
            prst.setString(2,winChance);
            prst.setString(3,betAmount);
            prst.setString(4,rollResult);
            prst.setString(5,result);
            prst.setString(6,profitOrLossAmount);
            prst.setString(7,balance);
            prst.execute();
            closeConnection();
        
            return true;
            // TODO code application logic here
        } catch (SQLException ex) {
        closeConnection();
        
            Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }
    
    public boolean insertIntoResponses(String uid,String result, String balance){
          try {
              this.connection();
            String query="insert into responses values (?,?,?)";
            PreparedStatement prst=con.prepareStatement(query);
            prst.setString(1,uid);
            prst.setString(2,result);
            prst.setString(3,balance);
            prst.execute();
            closeConnection();
        
            return true;
            // TODO code application logic here
        } catch (SQLException ex) {
            closeConnection();
        
            Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }
    
    public boolean deleteFromRequests(String userId)    {
        this.connection();
        PreparedStatement prst=null;
        String query="delete from requests where requestid=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
      
        prst.setString(1,userId);
       
        int rows=prst.executeUpdate();
        closeConnection();
        
        if (rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
        	return false;
            
        }
	
    }
    
    public boolean deleteFromResponses(String userId)    {
        this.connection();
        PreparedStatement prst=null;
        String query="delete from responses where requestid=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
      
        prst.setString(1,userId);
       
        int rows=prst.executeUpdate();
        closeConnection();
        
        if (rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
        	return false;
            
        }
	
    }
    
    public boolean insertIntoRequests(String uid,String command, String yesOrNo,String visit){
          try {
              this.connection();
            String query="insert into requests values (?,?,?,?)";
            PreparedStatement prst=con.prepareStatement(query);
            prst.setString(1,uid);
            prst.setString(2,command);
            prst.setString(3,yesOrNo);
            prst.setString(4, visit);
            prst.execute();
            closeConnection();
        
            return true;
            // TODO code application logic here
        } catch (SQLException ex) {
            closeConnection();
        
            Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }

    //-------------------------------Test Functions------------------------------
        
    public ArrayList<Request> getRequestsTest(){
        connection();
          try {
            String query="select * from testRequests where visitedyesorno='n' or visitedyesorno='N'  ";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            ArrayList<Request> list=new ArrayList<Request>();
            while(rs.next()){
                String id=rs.getString(1);
                String command=rs.getString(2);
                String delete=rs.getString(3);
                String visit=rs.getString(4);
                Request r=new Request(id,command,delete,visit);
                list.add(r);
            }
            closeConnection();
            return list;
        } catch (Exception ex) {
            System.err.println(ex);
            closeConnection();
            return new ArrayList<Request>();
        }
        
        
    }
 
    public ArrayList<Request> deleteRequestsTest(){
        connection();
          try {
            String query="select * from testRequests where deleteyesorno='y'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            ArrayList<Request> list=new ArrayList<Request>();
            while(rs.next()){
                String id=rs.getString(1);
                String command=rs.getString(2);
                String delete=rs.getString(3);
                String visit=rs.getString(4);
                Request r=new Request(id,command,delete,visit);
                list.add(r);
            }
            closeConnection();
            return list;
        } catch (Exception ex) {
            System.err.println(ex);
            closeConnection();
            return new ArrayList<Request>();
        }
        
        
    }
 
    public boolean updateBalanceTest(String userID,String balance)    {
        this.connection();
        PreparedStatement prst=null;
        String query="update testbalances set bal=? where uid=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
       

        prst.setString(1,balance);
        prst.setString(2, userID);
       
        int rows=prst.executeUpdate();
        closeConnection();
        if(rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            closeConnection();
            e.printStackTrace();
            return false;
            
        }
	
        
    }
 
    public boolean updateVisitedTest(String userID)   {
        this.connection();
        PreparedStatement prst=null;
        String query="update testrequests set visitedyesorno='y' where requestid=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
       

        prst.setString(1, userID);
       
        int rows=prst.executeUpdate();
        closeConnection();
        
        if(rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
        	return false;
            
        }
	
        
    }
    
    public String getBalanceTest(String uid)   {
        try 
        {
            this.connection();
            String query="select bal from testBalances where uid='"+uid+"'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            String balance=null;
            if(rs.next()){
                balance=rs.getString(1);
                closeConnection();
        
                return balance;
            }
            else
                closeConnection();
        
                return balance;
        }
        catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
            return null;
            
        }
        
    }
    
    public ArrayList<Balance> getBalancesTest(){
          try {
            this.connection();
            String query="select * from testBalances";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
            ArrayList<Balance> list=new ArrayList<Balance>();
            while(rs.next()){
                String uid=rs.getString(1);
                String bal=rs.getString(2);
                Balance r=new Balance(uid,bal);
                list.add(r);
            }
            closeConnection();
        
            return list;
        } catch (Exception ex) {
            closeConnection();
        
            System.err.println(ex);
            return null;
        }
        
        
    }
    
    public boolean userExistTest(String userId){
        try {
            this.connection();
            String query="select * from testrequests where requestid='"+userId+"'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
           // ArrayList<Balance> list=new ArrayList<Balance>();
            if(rs.next()){
                closeConnection();
        
                return true;
            }
            closeConnection();
        
            return false;
        }
        catch(Exception e)
        {
            this.connection();
            e.printStackTrace();
            return false;        
        }
            
        
    }
    
    public boolean userExistInBalanceTest(String userId)    {
        
        try {
            connection();
            String query="select * from testbalances where uid='"+userId+"'";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(query);
           // ArrayList<Balance> list=new ArrayList<Balance>();
            if(rs.next()){
                closeConnection();
        
                return true;
            }
            closeConnection();
        
            return false;
        }
        catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
            return false;        
        }
            
        
    
    }
    
    public boolean insertIntoBalanacesTest(String uid,String balance){
          try {
              connection();
            String query="insert into testBalances(uid,bal) values (?,?)";
            PreparedStatement prst=con.prepareStatement(query);
            prst.setString(1,uid);
            prst.setString(2,balance);
            prst.execute();
            closeConnection();
        
            return true;
            // TODO code application logic here
        } catch (SQLException ex) {
            closeConnection();
        
            Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }
    
    public boolean insertIntoBetsTest(String uid,String winChance,String betAmount,String rollResult,String result,String  profitOrLossAmount, String balance){
          try {
              this.connection();
            String query="insert into testbets values (?,?,?,?,?,?,?)";
            PreparedStatement prst=con.prepareStatement(query);
            prst.setString(1,uid);
            prst.setString(2,winChance);
            prst.setString(3,betAmount);
            prst.setString(4,rollResult);
            prst.setString(5,result);
            prst.setString(6,profitOrLossAmount);
            prst.setString(7,balance);
            prst.execute();
            closeConnection();
        
            return true;
            // TODO code application logic here
        } catch (SQLException ex) {
        closeConnection();
        
            Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }
    
    public boolean insertIntoResponsesTest(String uid,String result, String balance){
          try {
              this.connection();
            String query="insert into testresponses values (?,?,?)";
            PreparedStatement prst=con.prepareStatement(query);
            prst.setString(1,uid);
            prst.setString(2,result);
            prst.setString(3,balance);
            prst.execute();
            closeConnection();
        
            return true;
            // TODO code application logic here
        } catch (SQLException ex) {
            closeConnection();
        
            Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }
    
    public boolean deleteFromRequestsTest(String userId)    {
        this.connection();
        PreparedStatement prst=null;
        String query="delete from testrequests where requestid=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
      
        prst.setString(1,userId);
       
        int rows=prst.executeUpdate();
        closeConnection();
        
        if (rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
        	return false;
            
        }
	
    }
    
    public boolean deleteFromResponsesTest(String userId)    {
        this.connection();
        PreparedStatement prst=null;
        String query="delete from testresponses where requestid=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
      
        prst.setString(1,userId);
       
        int rows=prst.executeUpdate();
        closeConnection();
        
        if (rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            closeConnection();
        
            e.printStackTrace();
        	return false;
            
        }
	
    }
    
    public boolean insertIntoRequestsTest(String uid,String command, String yesOrNo,String visit){
          try {
              this.connection();
            String query="insert into testrequests values (?,?,?,?)";
            PreparedStatement prst=con.prepareStatement(query);
            prst.setString(1,uid);
            prst.setString(2,command);
            prst.setString(3,yesOrNo);
            prst.setString(4, visit);
            prst.execute();
            closeConnection();
        
            return true;
            // TODO code application logic here
        } catch (SQLException ex) {
            closeConnection();
        
            Logger.getLogger(SqliteConnection.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }

    
}
