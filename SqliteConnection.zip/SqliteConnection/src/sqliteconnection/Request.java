package sqliteconnection;

import java.util.StringTokenizer;

public class Request {

    private String requestid;
    private String requestcommand;
    private String deleteyesorno;
    
    private String command;
    private double betRange;

    private String isVisitedYesOrNo;
    private String betAmount;
    private String dateTime;
    private String uid;
    
    public Request(String requestid, String requestcommand, String deleteyesorno,String isVisitedYesOrNo) {
        this.requestid = requestid;
        this.requestcommand = requestcommand;
        this.deleteyesorno = deleteyesorno;
        this.isVisitedYesOrNo=isVisitedYesOrNo;
        getData();
    }

    private void getData(){
        StringTokenizer idToken = new StringTokenizer(requestid,"-");
        StringTokenizer commandToken= new StringTokenizer(requestcommand," ");
        String range=null,amount;
            while (commandToken.hasMoreTokens()) {  
            command=commandToken.nextToken();
            range=commandToken.nextToken();
            betAmount=commandToken.nextToken();
            //System.out.println(type+"\t"+chanceFromDatabase+"\t"+betAmount);
            } 
            betRange=Double.parseDouble(range);
            //System.out.println(command+"Command "+betRange+"BetRange"+betAmount+"BetAmounnt\n");
            while(idToken.hasMoreTokens())
            {
                uid=idToken.nextToken();
                dateTime=idToken.nextToken();
            }
           // System.out.println("\nUser id"+uid + "\nData and Time"+dateTime+"\n\n\n");
    }
    
    @Override
    public String toString() {
        return "Request{" + "requestid=" + requestid + ", requestcommand=" + requestcommand + ", deleteyesorno=" + deleteyesorno + '}';
    }

    public String getRequestid() {
        return requestid;
    }

    public void setRequestid(String requestid) {
        this.requestid = requestid;
    }

    public String getRequestcommand() {
        return requestcommand;
    }

    public void setRequestcommand(String requestcommand) {
        this.requestcommand = requestcommand;
    }

    public String getDeleteyesorno() {
        return deleteyesorno;
    }

    public void setDeleteyesorno(String deleteyesorno) {
        this.deleteyesorno = deleteyesorno;
    }
    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public double getBetRange() {
        return betRange;
    }

    public void setBetRange(double betRange) {
        this.betRange = betRange;
    }

    public String getBetAmount() {
        return betAmount;
    }

    public void setBetAmount(String betAmount) {
        this.betAmount = betAmount;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getIsVisitedYesOrNo() {
        return isVisitedYesOrNo;
    }

    public void setIsVisitedYesOrNo(String isVisitedYesOrNo) {
        this.isVisitedYesOrNo = isVisitedYesOrNo;
    }
    
    
    
}
