package sqliteconnection;

public class Balance {

    private String uid;
    private String bal;

    public Balance(String uid, String bal) {
        this.uid = uid;
        this.bal = bal;
    }

    @Override
    public String toString() {
        return "Request{" + "uid=" + uid + ", bal=" + bal + '}';
    }

    
    
    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getBal() {
        return bal;
    }

    public void setBal(String bal) {
        this.bal = bal;
    }
    
    
    
    
}
